<?php
require_once "../include/database.php";
class SPayables{	
    private $conn;
    public function __construct(){
        $this->conn = new Database();
        $this->conn = $this->conn->getmyDB();
    }
    public  function getSPP_list(){
        $stmt =  $this->conn->prepare("SELECT sp.*,sb.bank_account_no,sb.bank_name,os.shop_name FROM store_payables sp 
                                        INNER JOIN  oc_seller os 
                                            ON os.seller_id=sp.seller_id 
                                        INNER JOIN store_orders so 
                                            ON sp.seller_id=so.seller_id and sp.order_id=so.order_id
                                        INNER JOIN seller_branch sb 
                                            ON sb.id=so.branch_id 
                                        WHERE sp.status=:status order by sp.`date` desc") ;
        $stmt->bindValue(':status', 0);
        $stmt->execute();
        $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $row;
    }
    public  function PayTransfer($seller_id,$order_id,$payableId,$bank_name,$bank_account_no,$amount,$reference_no){
        try {  
            $details="Payment transfered to Acc.# : ".$bank_account_no.", RF.#: ".$reference_no.", Order Id:".$order_id;
            $sw = $this->conn->prepare("INSERT INTO seller_wallet SET `desc` = :orderdesc, amount = :amount, seller_id=:seller_id, `date` = convert_tz(utc_timestamp(),'-08:00','+0:00')");
            $sw->bindValue(':orderdesc',  $details);
            $sw->bindValue(':amount', '-'.$amount);
            $sw->bindValue(':seller_id', $seller_id);
            $sw->execute();
            $sp = $this->conn->prepare("UPDATE store_payables SET status=:status,reference_number=:reference_no, `date` = convert_tz(utc_timestamp(),'-08:00','+0:00') WHERE id=:payableId");
            $sp->bindValue(':payableId', $payableId); 
            $sp->bindValue(':reference_no', $reference_no); 
            $sp->bindValue(':status', 1);
            $sp->execute();
            return "200";
        } catch(Exception $e){
            return $e;
        }
    }
}
?>