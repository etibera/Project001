<?php
require_once "../include/database.php";
class OrderStatus{
    private $conn;   
    public function __construct(){
        $this->conn = new Database();
        $this->conn = $this->conn->getmyDB();
    }
  public function GetOrderStatus() {
        $s = $this->conn->prepare("SELECT *,
                                    CASE WHEN type=0 THEN 'Admin' ELSE 'Seller' END AS typename 
                                FROM oc_order_status order by name asc");
        $s->execute();
        $status = $s->fetchAll(PDO::FETCH_ASSOC);
        return $status;   
    }
    public function DeleteOrderStatus($id){
        try{   
          $stmt = $this->conn->prepare("DELETE FROM oc_order_status WHERE order_status_id=:order_status_id");
          $stmt->bindValue(':order_status_id', $id);
          $stmt->execute();
          return "Successfully Deleted.";
        }catch(PDOexception $e){
             return $e;
        }
    }
    public function AddOrderStaus($name,$type){
        try{   
          $stmt = $this->conn->prepare("INSERT INTO oc_order_status SET name=:name,type=:type,language_id=1");
          $stmt->bindValue(':name', $name);
          $stmt->bindValue(':type', $type);
          $stmt->execute();
          return "Order Status Successfully Added.";
        }catch(PDOexception $e){
             return $e;
        }
    } 
    public function UpdateOrderStaus($name,$type,$id){
        try{   
          $stmt = $this->conn->prepare("UPDATE oc_order_status SET name=:name,type=:type WHERE order_status_id=:id");
          $stmt->bindValue(':name', $name);
          $stmt->bindValue(':type', $type);
          $stmt->bindValue(':id', $id);
          $stmt->execute();
          return "Order Status Successfully Updated.";
        }catch(PDOexception $e){
             return $e;
        }
    }
}