<?php
require_once "../include/database.php";   
class message { 
  private $conn;  
  public function __construct(){
    $this->conn = new Database();
    $this->conn = $this->conn->getmyDB(); 
  }  
  
  public function GetAdminMessagesCA($admin_id){
    $stmt = $this->conn->prepare("
      select * from(select * from (
      select IFNULL(sm.read,'') as `read`, sm.customer_id, CONCAT(c.firstname,' ',c.lastname) as fullname, sm.sender, sm.message,  DATE_FORMAT(sm.timestamp,'%b %d %Y %l:%i %p') as timestamp , sm.id as message_id from oc_message_inbox_ca sm INNER JOIN oc_customer c ON sm.customer_id = c.customer_id where admin_id  = :admin_id group by sm.customer_id,sm.timestamp order by sm.timestamp desc
      ) as views  group by views.customer_id order by views.timestamp desc) as views2 order by timestamp desc;"); 
    $stmt->bindValue(':admin_id', 0);
    $stmt->execute();
    $row=$stmt->fetchAll(PDO::FETCH_ASSOC); 

    $stmt2 = $this->conn->prepare("select admin_id,customer_id,COUNT(id) as unreads
      from oc_message_inbox_ca where admin_id = :admin_id and sender != :admin_id and ISNULL(`read`)
      group by admin_id,customer_id;");
    $stmt2->bindValue(':admin_id', 0);
    $stmt2->execute(); 
    $row2=$stmt2->fetchAll(PDO::FETCH_ASSOC);
    
 
    $results = array(
        'list' =>  $row,
        'unreads' =>  $row2,
    );

    return $results;
  }

  public function GetTotalUnreadsCA($admin_id){
    $stmt = $this->conn->prepare("select COUNT(id) as unreads from oc_message_inbox_ca where admin_id = :admin_id and ISNULL(`read`) and sender != :admin_id");
    $stmt->bindValue(':admin_id', 0);
    $stmt->execute();
    $row=$stmt->fetch(PDO::FETCH_ASSOC);
    return $row;
  }

   public function GetConversationsCA($admin_id,$customer_id){
    $stmt = $this->conn->prepare("select  sm.receiver,sm.customer_id, sm.admin_id, sm.sender, sm.message, DATE_FORMAT(sm.timestamp,'%b %d %Y %l:%i %p') as timestamp, sm.id as message_id from oc_message_inbox_ca sm where sm.admin_id  = :admin_id and  sm.customer_id = :customer_id order by timestamp asc;");
    $stmt->bindValue(':admin_id', 0);
    $stmt->bindValue(':customer_id', $customer_id);
    $stmt->execute();
    $row=$stmt->fetchAll(PDO::FETCH_ASSOC);
    return $row;
  }

  public function UpdateToIsReadCA($admin_id,$customer_id) {
    try {
      $stmt =$this->conn->prepare("UPDATE oc_message_inbox_ca SET `read` =  convert_tz(utc_timestamp(),'-08:00','+0:00') where admin_id = :admin_id and customer_id = :customer_id; and sender != :admin_id");
      $stmt->bindValue(':admin_id', 0);
      $stmt->bindValue(':customer_id', $customer_id);
      $stmt->execute(); 
      $status = "200";
    }catch(Exception $e){
          $status=$e;
    } 
        return $status;
  } 

  public function InsertMessageCA($admin_id,$customer_id,$message) {
    try {
      $stmt =$this->conn->prepare("INSERT INTO oc_message_inbox_ca SET receiver = :customer_id, sender = :admin_id, admin_id = :admin_id, customer_id = :customer_id, message = :message, timestamp = convert_tz(utc_timestamp(),'-08:00','+0:00'), `read` = NULL, `void` = NULL, `status` = 0;");
      $stmt->bindValue(':admin_id', 0);
      $stmt->bindValue(':customer_id', $customer_id);
      $stmt->bindValue(':message', $message);
      $stmt->execute();
      $status = "200";
    }catch(Exception $e){
          $status=$e;
    } 
        return $status;
  } 

  

}