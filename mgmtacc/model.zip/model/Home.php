<?php
require_once "../include/database.php";
class Home {
        private $conn;
   
        public function __construct()
        {
        $this->conn = new Database();
        $this->conn = $this->conn->getmyDB();
        }
        public  function order_status(){
                
                $s = $this->conn->prepare("SELECT * FROM oc_order_status");
        $s->execute();
        $status = $s->fetchAll(PDO::FETCH_ASSOC);
        return $status;
        }
   
	public  function total_order(){
		//global $db;
        $stmt =$this->conn->prepare("SELECT COUNT(*) AS total FROM oc_order WHERE order_status_id > 0");
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
	}
	public  function total_customers(){
		//global $db;
        $stmt = $this->conn->prepare("SELECT COUNT(customer_id) as total FROM oc_customer WHERE nexmo_status=:s");
        $stmt->bindValue(':s', 1);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
	}
	public  function total_sales(){
		//global $db;
        $stmt =$this->conn->prepare("SELECT SUM((SELECT oot.value from oc_order_total oot where oot.order_id= o.order_id and title='Total')) AS total FROM oc_order o WHERE order_status_id = :s");
        $stmt->bindValue(':s', 20);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return number_format($row['total'], 2);
	}
	public  function order_history(){
		//global $db;
		$stmt = $this->conn->prepare("SELECT o.order_id, CONCAT(o.firstname, ' ', o.lastname) AS customer, (SELECT os.name FROM oc_order_status os WHERE os.order_status_id = o.order_status_id) AS status, o.shipping_code,(SELECT oot.value from oc_order_total oot where oot.order_id= o.order_id and title='Total') AS total, o.currency_code, o.currency_value, o.date_added, o.date_modified FROM oc_order o WHERE o.order_status_id > 0 ORDER BY o.date_added DESC LIMIT 0, 500");
		$stmt->execute();
        $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $row;

	}
    public  function count_OlddataOrder($order_id){
        $total = array();
        $t = $this->conn->prepare("SELECT count(id) as total FROM store_orders WHERE order_id=:order_id");
        $t->bindValue(':order_id', $order_id);
        $t->execute();
        $total = $t->fetch(PDO::FETCH_ASSOC);
        return $total['total'];
    }
        public  function order_historyS($order_id,$customer_name,$orderstatus){
                //global $db;
                $qeury="SELECT o.order_id,CONCAT(o.firstname, ' ', o.lastname) AS customer,os.name AS status,o.shipping_code, o.total, o.currency_code, o.currency_value, o.date_added, o.date_modified FROM oc_order o LEFT JOIN oc_order_status os ON os.order_status_id = o.order_status_id WHERE o.order_status_id > 0 ";
                if($customer_name!="notset"){
                        $qeury.=" and CONCAT(o.firstname, ' ', o.lastname) like :customer_name ";
                }
                 if($order_id!="notset"){
                       $qeury.=" and o.order_id= :order_id ";
                }
                 if($orderstatus!="notset"){
                       $qeury.=" and o.order_status_id=:orderstatus ";
                }                
                $qeury.=" ORDER BY o.date_added DESC LIMIT 0, 500 ";

                $stmt = $this->conn->prepare($qeury);
                if($customer_name!="notset"){
                  $stmt->bindValue(':customer_name', '%'.$customer_name.'%');
                }
                if($order_id!="notset"){
                      $stmt->bindValue(':order_id', $order_id);
                }
                 if($orderstatus!="notset"){
                      $stmt->bindValue(':orderstatus', $orderstatus);
                }                  
                $stmt->execute();
        $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return $row;

        }

        public  function activity_list($datefrom,$dateto,$customer,$ip) {
        $sql="";
        $sql1="";
        $sql2="";
        $sql3="";
        if($customer != ''){
            $sql=" and (c.firstname LIKE :customer or c.lastname LIKE :customer)";
        }
        if($ip != ''){
            $sql1=" and a.ip LIKE :ip";
        }
         if($datefrom != '' && $dateto != ''){
            $sql3=" and a.date_added between :date and :date1";
        }
                
        $stmt = $this->conn->prepare("SELECT a.*,c.firstname,c.lastname from oc_customer_activity a inner join oc_customer c on a.customer_id = c.customer_id where a.activity_id is not null ".$sql.$sql1.$sql2.$sql3." order by a.date_added desc LIMIT 10");

                 if(!empty($customer)) {
                   $stmt->bindValue(':customer', '%'.$customer.'%');
                }
                 if(!empty($ip)) {
                   $stmt->bindValue(':ip', '%'.$ip.'%');
                }
                 if(!empty($datefrom) && !empty($dateto)) {
                   $stmt->bindValue(':date', $datefrom.' 00:00:00');
                   $stmt->bindValue(':date1', $dateto.' 23:59:59');
                }
                      
              
                $stmt->execute();
                $row = $stmt->fetchAll(PDO::FETCH_ASSOC);       
                return $row;
    }

}