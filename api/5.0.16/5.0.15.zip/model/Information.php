<?php
require_once '../init.php';
class Information {
    function __construct(){
        $this->conn = new Database();
        $this->conn = $this->conn->getmyDB();
    }
    public function get_information($information_id){
        $data = array();
        $stmt = $this->conn->prepare("SELECT id.information_id, id.title, id.description FROM oc_information i LEFT JOIN oc_information_description id ON (i.information_id = id.information_id)
        WHERE  i.status = 1 AND id.information_id = :iid ORDER BY i.sort_order, LCASE(id.title) ASC");
        $stmt->bindValue(':iid', (int) $information_id);
        $stmt->execute();
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
        $data = array(
            'title' => html_entity_decode(utf8_decode($data['title'])),
            'description' => html_entity_decode(utf8_decode($data['description']))
        );
        return $data;
    }
}
$information = new Information();